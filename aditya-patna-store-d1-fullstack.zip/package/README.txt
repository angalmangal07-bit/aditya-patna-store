ADITYA PATNA STORE — D1 ENQUIRY VERSION

This package keeps your existing site design and adds:
- POST /api/enquiries -> saves customer enquiries to Cloudflare D1
- GET /api/enquiries -> admin-only enquiry list
- /api/admin/verify -> checks the Worker secret
- WhatsApp enquiry still opens after a successful save

Before deployment:
1. Put your real D1 database ID in wrangler.jsonc (database_name is already aditya-store-db).
2. Create a Worker secret named ADMIN_PASSWORD and choose a new admin password.
3. Deploy with Wrangler: npx wrangler deploy

The old static Worker can remain untouched until this version is tested.
