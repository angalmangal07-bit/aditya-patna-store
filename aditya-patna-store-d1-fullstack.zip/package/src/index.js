const jsonHeaders = { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store" };

function response(data, status=200){ return new Response(JSON.stringify(data), {status, headers: jsonHeaders}); }

async function requireAdmin(request, env){
  const supplied = request.headers.get("X-Admin-Password") || "";
  return supplied && env.ADMIN_PASSWORD && supplied === env.ADMIN_PASSWORD;
}

export default {
  async fetch(request, env){
    const url = new URL(request.url);
    if (url.pathname === "/api/enquiries" && request.method === "POST") {
      try {
        const b = await request.json();
        const name=String(b.name||"").trim(), phone=String(b.phone||"").trim(), product=String(b.product||"").trim(), requirement=String(b.requirement||"").trim(), area=String(b.area||"").trim();
        if(!name||!phone||!product||!requirement||!area) return response({error:"All fields are required"},400);
        await env.DB.prepare("INSERT INTO enquiries (name,phone,product,requirement,area) VALUES (?,?,?,?,?)").bind(name,phone,product,requirement,area).run();
        return response({ok:true});
      } catch(e) { return response({error:"Invalid request"},400); }
    }
    if (url.pathname === "/api/admin/verify" && request.method === "POST") {
      try { const b=await request.json(); return response({ok:String(b.password||"")===String(env.ADMIN_PASSWORD||"")}, String(b.password||"")===String(env.ADMIN_PASSWORD||"") ? 200 : 401); }
      catch(e){ return response({ok:false},400); }
    }
    if (url.pathname === "/api/enquiries" && request.method === "GET") {
      if(!(await requireAdmin(request,env))) return response({error:"Unauthorized"},401);
      const {results}=await env.DB.prepare("SELECT id,name,phone,product,requirement,area,created_at FROM enquiries ORDER BY id DESC LIMIT 200").all();
      return response({enquiries:results});
    }
    return env.ASSETS.fetch(request);
  }
};
