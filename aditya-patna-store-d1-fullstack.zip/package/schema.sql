CREATE TABLE IF NOT EXISTS enquiries (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  phone TEXT NOT NULL,
  product TEXT NOT NULL,
  requirement TEXT NOT NULL,
  area TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
